
#ifndef _ABIBITS_BLKSIZE_T_H
#define _ABIBITS_BLKSIZE_T_H

// TODO: use int64_t?
typedef long blksize_t;

#endif // _ABIBITS_BLKSIZE_T_H

