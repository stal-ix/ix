
#ifndef _ABIBITS_DEV_T_H
#define _ABIBITS_DEV_T_H

typedef unsigned long dev_t;

#endif // _ABIBITS_DEV_T_H

