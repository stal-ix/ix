
#ifndef _ABIBITS_MODE_T_H
#define _ABIBITS_MODE_T_H

typedef int mode_t;

#endif // _ABIBITS_MODE_T_H

