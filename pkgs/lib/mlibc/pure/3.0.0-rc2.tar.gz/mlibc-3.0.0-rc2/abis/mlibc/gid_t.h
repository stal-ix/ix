
#ifndef _ABIBITS_GID_T_H
#define _ABIBITS_GID_T_H

typedef unsigned int gid_t;

#endif // _ABIBITS_GID_T_H

