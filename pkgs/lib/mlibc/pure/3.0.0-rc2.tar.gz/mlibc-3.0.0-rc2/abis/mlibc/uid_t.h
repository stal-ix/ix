
#ifndef _ABIBITS_UID_T_H
#define _ABIBITS_UID_T_H

typedef unsigned int uid_t;

#endif // _ABIBITS_UID_T_H

