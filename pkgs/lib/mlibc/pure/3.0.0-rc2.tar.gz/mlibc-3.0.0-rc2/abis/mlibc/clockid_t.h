#ifndef _ABIBITS_CLOCKID_T_H
#define _ABIBITS_CLOCKID_T_H

typedef long clockid_t;

#endif /* _ABIBITS_CLOCKID_T_H */

