#ifndef _ABIBITS_BLKCNT_T_H
#define _ABIBITS_BLKCNT_T_H

// TODO: use int64_t?
typedef long blkcnt_t;

#endif // _ABIBITS_BLKCNT_T_H
