
#ifndef _ABIBITS_INO_T_H
#define _ABIBITS_INO_T_H

// TODO: use (u)int64_t?
typedef long ino_t;

#endif // _ABIBITS_INO_T_H

