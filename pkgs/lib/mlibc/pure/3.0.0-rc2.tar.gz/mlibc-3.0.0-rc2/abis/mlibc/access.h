#ifndef _ABIBITS_ACCESS_H
#define _ABIBITS_ACCESS_H

#define F_OK 1
#define R_OK 2
#define W_OK 4
#define X_OK 8

#endif // _ABIBITS_ACCESS_H
