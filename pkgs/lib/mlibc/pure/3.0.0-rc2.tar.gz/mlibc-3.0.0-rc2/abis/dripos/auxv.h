#ifndef _ABIBITS_AUXV_H
#define _ABIBITS_AUXV_H

#define AT_SECURE 23
#define AT_RANDOM 25
#define AT_EXECFN 31

#endif
