#ifndef _ABIBITS_BLKCNT_T_H
#define _ABIBITS_BLKCNT_T_H

#include <bits/types.h>

typedef __mlibc_int64 blkcnt_t;

#endif // _ABIBITS_BLKCNT_T_H
