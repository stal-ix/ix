
#ifndef _ABIBITS_NLINK_T_H
#define _ABIBITS_NLINK_T_H

typedef unsigned long nlink_t;

#endif // _ABIBITS_NLINK_T_H

