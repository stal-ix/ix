
#ifndef _ABIBITS_DEV_T_H
#define _ABIBITS_DEV_T_H

#include <bits/types.h>

typedef __mlibc_uint64 dev_t;

#endif // _ABIBITS_DEV_T_H

