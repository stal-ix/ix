
#ifndef _ABIBITS_PID_T_H
#define _ABIBITS_PID_T_H

typedef int pid_t;

#endif // _ABIBITS_PID_T_H

