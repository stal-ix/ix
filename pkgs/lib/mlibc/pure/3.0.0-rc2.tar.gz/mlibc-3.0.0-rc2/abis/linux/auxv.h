#ifndef _ABIBITS_AUXV_H
#define _ABIBITS_AUXV_H

#define AT_PLATFORM 15
#define AT_HWCAP 16
#define AT_CLKTCK 17
#define AT_FPUCW 18
#define AT_SECURE 23
#define AT_RANDOM 25
#define AT_EXECFN 31
#define AT_SYSINFO_EHDR 33

#endif // _ABIBITS_AUXV_H
