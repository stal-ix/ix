#ifndef _ABIBITS_FSFILCNT_T_H
#define _ABIBITS_FSFILCNT_T_H

#include <bits/types.h>

typedef __mlibc_uint64 fsfilcnt_t;

#endif /* _ABIBITS_FSFILCNT_T_H */
