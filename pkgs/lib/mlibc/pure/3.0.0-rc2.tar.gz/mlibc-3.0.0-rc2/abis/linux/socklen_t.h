#ifndef _ABIBITS_SOCKLEN_T_H
#define _ABIBITS_SOCKLEN_T_H

typedef unsigned socklen_t;

#endif /* _ABIBITS_SOCKLEN_T_H */
