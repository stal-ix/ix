
#ifndef _ABIBITS_BLKSIZE_T_H
#define _ABIBITS_BLKSIZE_T_H

typedef long blksize_t;

#endif // _ABIBITS_BLKSIZE_T_H

