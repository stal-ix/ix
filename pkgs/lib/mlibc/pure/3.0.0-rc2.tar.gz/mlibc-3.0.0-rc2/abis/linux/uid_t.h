
#ifndef _ABIBITS_UID_T_H
#define _ABIBITS_UID_T_H

typedef int uid_t;

#endif // _ABIBITS_UID_T_H

