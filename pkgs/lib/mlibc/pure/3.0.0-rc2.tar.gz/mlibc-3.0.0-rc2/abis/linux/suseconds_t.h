#ifndef _ABIBITS_SUSECONDS_T_H
#define _ABIBITS_SUSECONDS_T_H

#include <bits/types.h>

typedef __mlibc_int64 suseconds_t;

#endif /* _ABIBITS_SUSECONDS_T_H */
