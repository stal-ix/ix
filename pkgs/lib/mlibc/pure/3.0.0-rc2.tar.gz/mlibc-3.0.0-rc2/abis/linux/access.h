#ifndef _ABIBITS_ACCESS_H
#define _ABIBITS_ACCESS_H

#define F_OK 0
#define X_OK 1
#define W_OK 2
#define R_OK 4

#endif // _ABIBITS_ACCESS_H
