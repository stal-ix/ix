#ifndef _ABIBITS_FSBLKCNT_T_H
#define _ABIBITS_FSBLKCNT_T_H

#include <bits/types.h>

typedef __mlibc_uint64 fsblkcnt_t;

#endif /* _ABIBITS_FSBLKCNT_T_H */
