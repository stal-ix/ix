
#ifndef _ABIBITS_MODE_T_H
#define _ABIBITS_MODE_T_H

typedef unsigned int mode_t;

#endif // _ABIBITS_MODE_T_H

