
#ifndef _ABIBITS_INO_T_H
#define _ABIBITS_INO_T_H

#include <bits/types.h>

typedef __mlibc_uint64 ino_t;

#endif // _ABIBITS_INO_T_H

