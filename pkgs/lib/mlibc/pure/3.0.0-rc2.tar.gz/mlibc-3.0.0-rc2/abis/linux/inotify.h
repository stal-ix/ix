#ifndef _ABIBITS_INOTIFY_H
#define _ABIBITS_INOTIFY_H

#include <abi-bits/fcntl.h>

#define IN_CLOEXEC O_CLOEXEC
#define IN_NONBLOCK O_NONBLOCK

#endif // _ABIBITS_INOTIFY_H
