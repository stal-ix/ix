
#ifndef  _LINUX_MAJOR_H
#define  _LINUX_MAJOR_H

#define TTY_MAJOR 4
#define INPUT_MAJOR 13

#endif // _LINUX_MAJOR_H

