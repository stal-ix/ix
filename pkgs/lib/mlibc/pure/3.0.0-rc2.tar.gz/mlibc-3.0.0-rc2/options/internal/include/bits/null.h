
#ifndef MLIBC_NULL_H
#define MLIBC_NULL_H

#define __need_NULL
#include <stddef.h>

#endif // MLIBC_NULL_H

