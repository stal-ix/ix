#ifndef MLIBC_WINT_T_H
#define MLIBC_WINT_T_H

#define __need_wint_t
#include <stddef.h>

#endif // MLIBC_WINT_T_H
