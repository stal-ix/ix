#ifndef MLIBC_WCHAR_H
#define MLIBC_WCHAR_H

#include <bits/types.h>

#define WCHAR_MAX      __MLIBC_WCHAR_MAX
#define WCHAR_MIN      __MLIBC_WCHAR_MIN

#endif // MLIBC_WCHAR_H
