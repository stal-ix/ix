
#ifndef MLIBC_WCHAR_T_H
#define MLIBC_WCHAR_T_H

#define __need_wchar_t
#include <stddef.h>

#endif // MLIBC_WCHAR_T_H

