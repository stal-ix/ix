#ifndef MLIBC_STACK_PROTECTOR_HPP
#define MLIBC_STACK_PROTECTOR_HPP

namespace mlibc {

void initStackGuard(void *);

} // namespace mlibc

#endif // MLIBC_STACK_PROTECTOR_HPP
