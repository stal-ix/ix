
#ifndef MLIBC_SSIZE_T_H
#define MLIBC_SSIZE_T_H

// TODO: use ptrdiff_t instead?
typedef long ssize_t;

#endif // MLIBC_SSIZE_T_H

