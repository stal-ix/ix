#ifndef MLIBC_OFF_T_H
#define MLIBC_OFF_T_H

// TODO: use something like int64_t instead?
typedef long off_t;
typedef long off64_t;

#endif // MLIBC_OFF_T_H
