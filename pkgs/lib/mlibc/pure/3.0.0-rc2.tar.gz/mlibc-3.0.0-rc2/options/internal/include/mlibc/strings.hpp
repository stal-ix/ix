#ifndef MLIBC_STRINGS
#define MLIBC_STRINGS

#include <bits/size_t.h>

namespace mlibc {

int strncasecmp(const char *a, const char *b, size_t size);

} // namespace mlibc

#endif // MLIBC_STRINGS
