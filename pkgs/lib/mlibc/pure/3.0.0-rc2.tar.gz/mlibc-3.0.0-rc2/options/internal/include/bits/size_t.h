#ifndef MLIBC_SIZE_T_H
#define MLIBC_SIZE_T_H

#define __need_size_t
#include <stddef.h>

#endif // MLIBC_SIZE_T_H
