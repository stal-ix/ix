#ifndef MLIBC_GLIBC_SIGNAL_H
#define MLIBC_GLIBC_SIGNAL_H

#ifdef __cplusplus
extern "C" {
#endif

int tgkill(int, int, int);

#ifdef __cplusplus
}
#endif

#endif // MLIBC_GLIBC_SIGNAL_H
