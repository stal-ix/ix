#include <bits/ensure.h>
#include <printf.h>

size_t parse_printf_format(const char * __restrict, size_t, int * __restrict) {
	__ensure(!"Not implemented");
	__builtin_unreachable();
}
