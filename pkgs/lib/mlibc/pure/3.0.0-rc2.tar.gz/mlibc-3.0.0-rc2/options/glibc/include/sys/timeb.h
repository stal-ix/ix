#ifndef _SYS_TIMEB_H
#define _SYS_TIMEB_H

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif // _SYS_TIMEB_H
