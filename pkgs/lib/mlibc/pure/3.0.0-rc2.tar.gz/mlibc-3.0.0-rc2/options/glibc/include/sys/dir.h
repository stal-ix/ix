#ifndef _SYS_DIR_H
#define _SYS_DIR_H

#include <dirent.h>

#define direct  dirent

#endif
