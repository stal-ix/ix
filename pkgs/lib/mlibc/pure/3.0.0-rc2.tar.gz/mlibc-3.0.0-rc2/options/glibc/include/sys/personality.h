#ifndef _SYS_PERSONALITY_H
#define _SYS_PERSONALITY_H

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif // _SYS_PERSONALITY_H
