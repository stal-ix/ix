#ifndef MLIBC_ENVIRONMENT_HPP
#define MLIBC_ENVIRONMENT_HPP

namespace mlibc {

int putenv(char *string);

} // namespace mlibc

#endif // MLIBC_ENVIRONMENT_HPP
