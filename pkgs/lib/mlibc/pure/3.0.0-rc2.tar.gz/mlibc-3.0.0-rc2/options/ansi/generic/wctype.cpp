
#include <wctype.h>
#include <bits/ensure.h>
#include <mlibc/debug.hpp>
#include <frg/string.hpp>

wctrans_t wctrans(const char *) MLIBC_STUB_BODY
wint_t towctrans(wint_t, wctrans_t) MLIBC_STUB_BODY

