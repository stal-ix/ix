
#ifndef _ALLOCA_H
#define _ALLOCA_H

#define alloca __builtin_alloca

#endif // _ALLOCA_H

