#include <math.h>

long long llroundf(float x)
{
	return roundf(x);
}
