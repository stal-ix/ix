
#ifndef MLIBC_TIME_T
#define MLIBC_TIME_T

typedef long time_t;

#endif

