#include <math.h>

float tgammaf(float x)
{
	return tgamma(x);
}
