#include <math.h>

long double nanl(const char *s)
{
	return NAN;
}
