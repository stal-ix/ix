#include <math.h>

double nan(const char *s)
{
	return NAN;
}
